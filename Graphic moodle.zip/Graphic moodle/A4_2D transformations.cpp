#include<iostream>
#include<cmath>
#include<graphics.h>
#include<string.h>
using namespace std;

class transformation
{
    int x1,y1,x2,y2,x3,y3,x4,y4;
    int x_1,y_1,x_2,y_2,x_3,y_3,x_4,y_4;
    void getcordinates1();
    void getcordinates2();
public:
    void ddaline(int,int,int,int);
    void translation();
    void scaling();
    void rotation();
    void shear();
};

void transformation :: ddaline(int x1,int y1,int x2,int y2)
{
    int dx,dy,steps,xinc,yinc;
    int i;
    int x,y;

    dx = abs(x2-x1);
    dy = abs(y2-y1);
    if(dx>dy)
        steps = dx;
    else
        steps = dy;
    x = x1;
    y = y1;
    xinc = dx/steps;
    yinc = dy/steps;

    for(i=0;i<steps;i++)
    {
            putpixel(x,y,RED);
            x = x + xinc;
            y = y + yinc;
    }

}

void transformation :: getcordinates1()
{
    cout<<"\nEnter x1 and y1 coordinates for first point ";
    cin>>x1>>y1;
    cout<<"\nEnter x2 and y2 coordinates for second point ";
    cin>>x2>>y2;
}

void transformation :: getcordinates2()
{
    cout<<"\nEnter x1 and y1 cordinates for first point ";
    cin>>x1>>y1;
    cout<<"\nEnter x2 and y2 cordinates for second point ";
    cin>>x2>>y2;
    cout<<"\nEnter x3 and y3 cordinates for third point ";
    cin>>x3>>y3;
    cout<<"\nEnter x4 and y4 cordinates for fourth point ";
    cin>>x4>>y4;
}

void transformation :: translation()
{
    int tx,ty;

    getcordinates1();
    cleardevice();
    ddaline(x1,y1,x2,y2);

    cout<<"\nEnter translation factor for X-axis ";
    cin>>tx;
    cout<<"\nEnter translation factor for Y-axis ";
    cin>>ty;

    x_1 = x1 + tx;
    y_1 = y1 + ty;
    x_2 = x2 + tx;
    y_2 = y2 + ty;
    delay(1500);
    cleardevice();
    ddaline(x_1,y_1,x_2,y_2);
}

void transformation :: scaling()
{
    int Sx,Sy,sum;
    int s[3][3],arr[4][3],result[4][3];
    int i,j,k;
    sum = 0;

    getcordinates2();
    cleardevice();
    ddaline(x1,y1,x2,y2);
    ddaline(x2,y2,x3,y3);
    ddaline(x4,y4,x3,y3);
    ddaline(x1,y1,x4,y4);

    arr[0][0] = x1
    arr[0][1] = y1;
    arr[0][2] = 1;
    arr[1][0] = x2;
    arr[1][1] = y2;
    arr[1][2] = 1;
    arr[2][0] = x3;
    arr[2][1] = y3;
    arr[2][2] = 1;
    arr[3][0] = x4;
    arr[3][1] = y4;
    arr[3][2] = 1;

    cout<<"\nEnter Scaling factor Sx ";
    cin>>Sx;
    cout<<"\nEnter Scaling factor Sy ";
    cin>>Sy;

    s[0][0] = Sx;
    s[0][1] = 0;
    s[0][2] = 0;
    s[1][0] = 0;
    s[1][1] = Sy;
    s[1][2] = 0;
    s[2][0] = 0;
    s[2][1] = 0;
    s[2][2] = 1;

    for(i=0;i<4;i++)
    {
        for(j=0;j<3;j++)
        {
            sum = 0;
            for(k=0;k<3;k++)
            {
                sum = sum + arr[i][k]*s[k][j];
            }
            result[i][j] = sum;
        }
    }

    x_1 = result[0][0];
    y_1 = result[0][1];
    x_2 = result[1][0];
    y_2 = result[1][1];
    x_3 = result[2][0];
    y_3 = result[2][1];
    x_4 = result[3][0];
    y_4 = result[3][1];

    delay(1500);
    cleardevice();
    ddaline(x_1,y_1,x_2,y_2);
    ddaline(x_2,y_2,x_3,y_3);
    ddaline(x_4,y_4,x_3,y_3);
    ddaline(x_1,y_1,x_4,y_4);
}

void transformation :: rotation()
{
    int angle;

    getcordinates1();
    cleardevice();
    ddaline(x1,y1,x2,y2);

    cout<<"\nEnter the rotation angle ";
    cin>>angle;

    angle = (angle*3.14)/180.0;
    x_1 = x1;
    y_1 = y1;
    x_2 = x1 + ((x2 - x1)*cos(angle) - (y2 - y1)*sin(angle));
    y_2 = y1 + ((x2 - x1)*sin(angle) + (y2 - y1)*cos(angle));

    delay(1500);
    cleardevice();
    ddaline(x_1,y_1,x_2,y_2);
}

void transformation :: shear()
{
    int arr[4][3],sh[3][3],result[4][3];
    int a,b;
    int i,j,k,sum;
    char ch,ans;

    do
    {
        getcordinates2();

        arr[0][0] = x1;
        arr[0][1] = y1;
        arr[0][2] = 1;
        arr[1][0] = x2;
        arr[1][1] = y2;
        arr[1][2] = 1;
        arr[2][0] = x3;
        arr[2][1] = y3;
        arr[2][2] = 1;
        arr[3][0] = x4;
        arr[3][1] = y4;
        arr[3][2] = 1;


        cout<<"\nWhich Shearing transformation do you want to perform X-shear or Y-shear(for X-shear enter x and for Y-shear enter y) ";
        cin>>ch;

        cleardevice();
        ddaline(x1,y1,x2,y2);
        ddaline(x2,y2,x3,y3);
        ddaline(x4,y4,x3,y3);
        ddaline(x1,y1,x4,y4);


        if(ch == 'x' || ch == 'X')
        {
            cout<<"\nEnter the constant value for X-shearing ";
            cin>>b;

            sh[0][0] = 1;
            sh[0][1] = 0;
            sh[0][2] = 0;
            sh[1][0] = b;
            sh[1][1] = 1;
            sh[1][2] = 0;
            sh[2][0] = 0;
            sh[2][1] = 0;
            sh[2][2] = 1;

            for(i=0;i<4;i++)
            {
                for(j=0;j<3;j++)
                {
                    sum = 0;
                    for(k=0;k<3;k++)
                    {
                        sum = sum + arr[i][k]*sh[k][j];
                    }
                    result[i][j] = sum;
                }//for(j...

            }//for(i....

            x_1 = result[0][0];
            y_1 = result[0][1];
            x_2 = result[1][0];
            y_2 = result[1][1];
            x_3 = result[2][0];
            y_3 = result[2][1];
            x_4 = result[3][0];
            y_4 = result[3][1];

            delay(1500);
            cleardevice();
            //ddaline(x_1,y_1,x_2,y_2);
            //ddaline(x_2,y_2,x_3,y_3);
            //ddaline(x_4,y_4,x_3,y_3);
            //ddaline(x_1,y_1,x_3,y_3);
            line(x_1,y_1,x_2,y_2);
            line(x_1,y_1,x_4,y_4);
            line(x_2,y_2,x_3,y_3);
            line(x_3,y_3,x_4,y_4);
        }
        else if(ch == 'y' || ch == 'Y')
        {
            cout<<"\nEnter the constant value for Y-shearing ";
            cin>>a;

            sh[0][0] = 1;
            sh[0][1] = a;
            sh[0][2] = 0;
            sh[1][0] = 0;
            sh[1][1] = 1;
            sh[1][2] = 0;
            sh[2][0] = 0;
            sh[2][1] = 0;
            sh[2][2] = 1;

            for(i=0;i<4;i++)
            {
                for(j=0;j<3;j++)
                {
                    sum = 0;
                    for(k=0;k<3;k++)
                    {
                        sum = sum + arr[i][k]*sh[k][j];
                    }
                    result[i][j] = sum;
                }//for(j...

            }//for(i....

            x_1 = result[0][0];
            y_1 = result[0][1];
            x_2 = result[1][0];
            y_2 = result[1][1];
            x_3 = result[2][0];
            y_3 = result[2][1];
            x_4 = result[3][0];
            y_4 = result[3][1];

            delay(1500);
            cleardevice();
            //ddaline(x_1,y_1,x_2,y_2);
            //ddaline(x_2,y_2,x_3,y_3);
            //ddaline(x_4,y_4,x_3,y_3);
            //ddaline(x_1,y_1,x_3,y_3);

            line(x_1,y_1,x_2,y_2);
            line(x_1,y_1,x_4,y_4);
            line(x_2,y_2,x_3,y_3);
            line(x_3,y_3,x_4,y_4);
        }
        else
            cout<<"\nWrong choice";

        cout<<"\nDo you want to continue(y/n)? ";
        cin>>ans;

    }while(ans == 'y' || ans == 'Y');
}


int main()
{
    int ch;
    int gd = DETECT,gm;
        initgraph(&gd,&gm,NULL);

    transformation tr;
    do
    {
        cout<<"\n------2-D Transformation------";
        cout<<"\n1.Translation";
        cout<<"\n2.Scaling";
        cout<<"\n3.Rotation";
        cout<<"\n4.Shearing";
        cout<<"\n5.Exit";
        cout<<"\nEnter your choice ";
        cin>>ch;

        switch(ch)
        {
        case 1:
            tr.translation();
            break;
        case 2:
            tr.scaling();
            break;
        case 3:
            tr.rotation();
            break;
        case 4:
            tr.shear();
            break;
        case 5:
            break;
        default :
            cout<<"\nWrong choice";
        }//switch
    }while(ch != 5);

    return 0;
};
