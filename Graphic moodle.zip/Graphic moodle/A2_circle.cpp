#include<stdio.h>
#include<graphics.h>
#include<stdlib.h>
#include<math.h>
//#include<dos.h>
//#include<process>
#include<iostream>
//#include<conio.h>
using namespace std;


class pixel    //pixel class
{
	protected:
		int x,y;
	public:
	void getpixel();
};

//definition of getline function out of class
void pixel :: getpixel()
{
	cout<<"\n enter the value of x:\t ";
	cin>>x;
	cout<<"\n enter the value of  y:\t ";
	cin>>y;
}

//class bre_cir is publicaly inherited
//from pixel class
class BRE_CIR:public pixel
{
	public:
		float rad;
		void drawcircle();
};

//definition of drawcircle function out of class
void BRE_CIR::drawcircle()
{
	float d;
	cout<<"Enter the radius of circle :";
	cin>>rad;
	d=3-2*rad;
	x=0;
	y=rad;
	do
	{
		delay(10);
		putpixel(200+x,200+y,RED);
		putpixel(200+y,200+x,RED);
		putpixel(200-y,200+x,RED);
		putpixel(200+x,200-y,RED);
		putpixel(200-x,200-y,RED);
		putpixel(200-y,200-x,RED);
		putpixel(200+y,200-x,RED);
		putpixel(200-x,200+y,RED);
		if(d<0)
		{
			d=d+(4*x)+6;
		}
		else
		{
			d=d+(4*(x-y))+10;
			y=y-1;
		}
		x=x+1;
	}while(x<y);
}

int main()  //main function
{
	int gd=DETECT,gm;
	initgraph(&gd,&gm,NULL);

	BRE_CIR c;    //object of derived class

	c.getpixel();   //call to getpixel
	c.drawcircle(); //call to drawcircle
	getch();
	return 0;

}
